$(document).ready(function() {

    window.touchStart = function() {
        $("#gjs").addClass('sidebar-collapsed');
    }

});