<?php

return [
    'title' => 'Master Layout',
];