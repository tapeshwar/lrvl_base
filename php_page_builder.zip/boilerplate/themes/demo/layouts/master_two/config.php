<?php

return [
    'title' => 'Master Layout Two',
];