<?php

return [
    'title' => 'Hello World',
    'category' => 'General',
    'icon' => 'fa fa-hand-peace-o',
];
