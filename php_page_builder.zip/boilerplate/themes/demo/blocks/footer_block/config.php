<?php

return [
    'title' => 'Footer Block',
    'category' => 'General',
    'icon' => 'fa fa-hand-peace-o',
];
