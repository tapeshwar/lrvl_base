<?php

return [
    'title' => 'Header Block',
    'category' => 'General',
    'icon' => 'fa fa-hand-peace-o',
];
