<?php

return [
    'title' => 'Body Block',
    'category' => 'General',
    'icon' => 'fa fa-hand-peace-o',
];
